/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!************************************!*\
  !*** ./source/Background/index.ts ***!
  \************************************/
__webpack_require__.r(__webpack_exports__);
/**
 * Background Service Worker
 * Manifest V3 使用 Service Worker 替代 Background Page
 */

// 监听扩展安装事件
chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === 'install') {
    console.log('Py Small Admin Login Helper 扩展已安装');
  } else if (details.reason === 'update') {
    console.log('Py Small Admin Login Helper 扩展已更新');
  }
});

// 监听来自 Popup 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getCookies') {
    // 处理获取 Cookie 的请求
    handleGetCookies(request.domains).then(sendResponse);
    return true; // 保持消息通道开放
  }
});

/**
 * 获取指定域名的 Cookies
 */
async function handleGetCookies(domains) {
  const allCookies = [];
  for (const domain of domains) {
    const cookies = await new Promise(resolve => {
      chrome.cookies.getAll({
        domain
      }, cookies => {
        resolve(cookies || []);
      });
    });
    allCookies.push(...cookies);
  }
  return allCookies;
}

// 导出类型供其他模块使用

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOztVQUFBO1VBQ0E7Ozs7O1dDREE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdELEU7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0FBLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDQyxXQUFXLENBQUNDLFdBQVcsQ0FBRUMsT0FBTyxJQUFLO0VBQ2xELElBQUlBLE9BQU8sQ0FBQ0MsTUFBTSxLQUFLLFNBQVMsRUFBRTtJQUNoQ0MsT0FBTyxDQUFDQyxHQUFHLENBQUMsbUNBQW1DLENBQUM7RUFDbEQsQ0FBQyxNQUFNLElBQUlILE9BQU8sQ0FBQ0MsTUFBTSxLQUFLLFFBQVEsRUFBRTtJQUN0Q0MsT0FBTyxDQUFDQyxHQUFHLENBQUMsbUNBQW1DLENBQUM7RUFDbEQ7QUFDRixDQUFDLENBQUM7O0FBRUY7QUFDQVAsTUFBTSxDQUFDQyxPQUFPLENBQUNPLFNBQVMsQ0FBQ0wsV0FBVyxDQUFDLENBQUNNLE9BQU8sRUFBRUMsTUFBTSxFQUFFQyxZQUFZLEtBQUs7RUFDdEUsSUFBSUYsT0FBTyxDQUFDRyxNQUFNLEtBQUssWUFBWSxFQUFFO0lBQ25DO0lBQ0FDLGdCQUFnQixDQUFDSixPQUFPLENBQUNLLE9BQU8sQ0FBQyxDQUFDQyxJQUFJLENBQUNKLFlBQVksQ0FBQztJQUNwRCxPQUFPLElBQUksQ0FBQyxDQUFDO0VBQ2Y7QUFDRixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0EsZUFBZUUsZ0JBQWdCQSxDQUFDQyxPQUFpQixFQUFvQztFQUNuRixNQUFNRSxVQUFtQyxHQUFHLEVBQUU7RUFFOUMsS0FBSyxNQUFNQyxNQUFNLElBQUlILE9BQU8sRUFBRTtJQUM1QixNQUFNSSxPQUFPLEdBQUcsTUFBTSxJQUFJQyxPQUFPLENBQTJCQyxPQUFPLElBQUs7TUFDdEVwQixNQUFNLENBQUNrQixPQUFPLENBQUNHLE1BQU0sQ0FBQztRQUFFSjtNQUFPLENBQUMsRUFBR0MsT0FBTyxJQUFLO1FBQzdDRSxPQUFPLENBQUNGLE9BQU8sSUFBSSxFQUFFLENBQUM7TUFDeEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDO0lBQ0ZGLFVBQVUsQ0FBQ00sSUFBSSxDQUFDLEdBQUdKLE9BQU8sQ0FBQztFQUM3QjtFQUVBLE9BQU9GLFVBQVU7QUFDbkI7O0FBRUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9weS1zbWFsbC1hZG1pbi1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9weS1zbWFsbC1hZG1pbi1icm93c2VyLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3B5LXNtYWxsLWFkbWluLWJyb3dzZXItZXh0ZW5zaW9uLy4vc291cmNlL0JhY2tncm91bmQvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHJlcXVpcmUgc2NvcGVcbnZhciBfX3dlYnBhY2tfcmVxdWlyZV9fID0ge307XG5cbiIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIi8qKlxyXG4gKiBCYWNrZ3JvdW5kIFNlcnZpY2UgV29ya2VyXHJcbiAqIE1hbmlmZXN0IFYzIOS9v+eUqCBTZXJ2aWNlIFdvcmtlciDmm7/ku6MgQmFja2dyb3VuZCBQYWdlXHJcbiAqL1xyXG5cclxuLy8g55uR5ZCs5omp5bGV5a6J6KOF5LqL5Lu2XHJcbmNocm9tZS5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKChkZXRhaWxzKSA9PiB7XHJcbiAgaWYgKGRldGFpbHMucmVhc29uID09PSAnaW5zdGFsbCcpIHtcclxuICAgIGNvbnNvbGUubG9nKCdQeSBTbWFsbCBBZG1pbiBMb2dpbiBIZWxwZXIg5omp5bGV5bey5a6J6KOFJyk7XHJcbiAgfSBlbHNlIGlmIChkZXRhaWxzLnJlYXNvbiA9PT0gJ3VwZGF0ZScpIHtcclxuICAgIGNvbnNvbGUubG9nKCdQeSBTbWFsbCBBZG1pbiBMb2dpbiBIZWxwZXIg5omp5bGV5bey5pu05pawJyk7XHJcbiAgfVxyXG59KTtcclxuXHJcbi8vIOebkeWQrOadpeiHqiBQb3B1cCDnmoTmtojmga9cclxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChyZXF1ZXN0LCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgPT4ge1xyXG4gIGlmIChyZXF1ZXN0LmFjdGlvbiA9PT0gJ2dldENvb2tpZXMnKSB7XHJcbiAgICAvLyDlpITnkIbojrflj5YgQ29va2llIOeahOivt+axglxyXG4gICAgaGFuZGxlR2V0Q29va2llcyhyZXF1ZXN0LmRvbWFpbnMpLnRoZW4oc2VuZFJlc3BvbnNlKTtcclxuICAgIHJldHVybiB0cnVlOyAvLyDkv53mjIHmtojmga/pgJrpgZPlvIDmlL5cclxuICB9XHJcbn0pO1xyXG5cclxuLyoqXHJcbiAqIOiOt+WPluaMh+WumuWfn+WQjeeahCBDb29raWVzXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVHZXRDb29raWVzKGRvbWFpbnM6IHN0cmluZ1tdKTogUHJvbWlzZTxjaHJvbWUuY29va2llcy5Db29raWVbXT4ge1xyXG4gIGNvbnN0IGFsbENvb2tpZXM6IGNocm9tZS5jb29raWVzLkNvb2tpZVtdID0gW107XHJcblxyXG4gIGZvciAoY29uc3QgZG9tYWluIG9mIGRvbWFpbnMpIHtcclxuICAgIGNvbnN0IGNvb2tpZXMgPSBhd2FpdCBuZXcgUHJvbWlzZTxjaHJvbWUuY29va2llcy5Db29raWVbXT4oKHJlc29sdmUpID0+IHtcclxuICAgICAgY2hyb21lLmNvb2tpZXMuZ2V0QWxsKHsgZG9tYWluIH0sIChjb29raWVzKSA9PiB7XHJcbiAgICAgICAgcmVzb2x2ZShjb29raWVzIHx8IFtdKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICAgIGFsbENvb2tpZXMucHVzaCguLi5jb29raWVzKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBhbGxDb29raWVzO1xyXG59XHJcblxyXG4vLyDlr7zlh7rnsbvlnovkvpvlhbbku5bmqKHlnZfkvb/nlKhcclxuZXhwb3J0IHt9O1xyXG4iXSwibmFtZXMiOlsiY2hyb21lIiwicnVudGltZSIsIm9uSW5zdGFsbGVkIiwiYWRkTGlzdGVuZXIiLCJkZXRhaWxzIiwicmVhc29uIiwiY29uc29sZSIsImxvZyIsIm9uTWVzc2FnZSIsInJlcXVlc3QiLCJzZW5kZXIiLCJzZW5kUmVzcG9uc2UiLCJhY3Rpb24iLCJoYW5kbGVHZXRDb29raWVzIiwiZG9tYWlucyIsInRoZW4iLCJhbGxDb29raWVzIiwiZG9tYWluIiwiY29va2llcyIsIlByb21pc2UiLCJyZXNvbHZlIiwiZ2V0QWxsIiwicHVzaCJdLCJzb3VyY2VSb290IjoiIn0=